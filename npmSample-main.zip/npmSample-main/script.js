
let names = ["Omid", "John", "Olivia", "Robbin", "Morice", "Barry", "Smith", "Debora"];
// let txt="<ol>";
// for (let index = 0; index < names.length; index++) {
//    txt+="<li>"+ names[index] + "</li>" ;

// }
// txt+="</ol>";

// document.getElementById("demo").innerHTML=txt;
names[0] = "Michaeal";
console.log(names[0]);
names[names.length - 1] = "Natasha";
console.log(names[names.length - 1]);

// OMID: Seed 3
let i;
for (i = 0; i < 10; i++) {
    if (i === 5) {
        continue;
    }
    console.log("in loop: " + i);


}
// console.log("out-side: " + i);
let y=4;
while (false) {
    y-=1;
    console.log(y);
}


console.log(txt.length);

console.log(fullnameArray.length);
console.log(fullnameArray[1]);


let txt="omid Lak";
let fullnameArray=txt.split(" ");
for (let index = 0; index < fullnameArray.length; index++) {
    console.log(fullnameArray[index]);
    
}



let table="<table><tr>";

for (let index = 0; index < array.length; index++) {
    const element = array[index];
    
}
table+="</tr>"